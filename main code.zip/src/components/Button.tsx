interface ButtonProps {
  number: string;
  onClick?: (value: string) => void;
  isDarkMode?: boolean;
}

function Button(props: ButtonProps) {
    return (
        <button
            className={`font-mono font-bold text-2xl w-16 h-16 rounded-md shadow-[2px_2px_0_0_rgba(80,80,80,0.5)] border-2 transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${props.isDarkMode ? 'bg-gray-600 hover:bg-gray-500 text-white border-gray-500' : 'bg-gray-300 hover:bg-gray-400 text-gray-900 border-gray-500'}`}
            onClick={() => props.onClick?.(props.number)}
        >
            {props.number}
        </button>
    )
}

export default Button;