import { useState, useEffect } from 'react';

interface DigitalClockProps {
  isDarkMode: boolean;
}

function DigitalClock({ isDarkMode }: DigitalClockProps) {
  const [time, setTime] = useState(new Date());
  const [isBlinking, setIsBlinking] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    // Blinking effect for the colon
    const blinkTimer = setInterval(() => {
      setIsBlinking(prev => !prev);
    }, 500);

    return () => {
      clearInterval(timer);
      clearInterval(blinkTimer);
    };
  }, []);

  const formatTime = (date: Date) => {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
  };

  const formatDate = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return date.toLocaleDateString('en-US', options);
  };

  return (
    <div className={`border-4 rounded-2xl shadow-[8px_8px_0_0_rgba(80,80,80,0.5)] p-8 w-[400px] h-[400px] flex flex-col items-center justify-center mt-20 transition-colors duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-600' : 'bg-gray-200 border-gray-700'}`}>
      {/* Digital Display Container */}
      <div className={`w-full p-6 rounded-lg border-4 shadow-inner mb-6 ${
        isDarkMode 
          ? 'bg-black border-green-600 shadow-[inset_0_0_20px_rgba(34,197,94,0.3)]' 
          : 'bg-gray-900 border-green-700 shadow-[inset_0_0_20px_rgba(34,197,94,0.2)]'
      }`}>
        {/* Time Display */}
        <div className={`text-5xl font-mono font-bold text-center tracking-widest ${
          isDarkMode ? 'text-green-400' : 'text-green-500'
        }`}>
          {formatTime(time).split(':').map((segment, index) => (
            <span key={index}>
              {segment}
              {index < 2 && (
                <span className={`transition-opacity duration-200 ${
                  isBlinking ? 'opacity-100' : 'opacity-30'
                }`}>
                  :
                </span>
              )}
            </span>
          ))}
        </div>
      </div>

      {/* Date Display */}
      <div className={`text-lg font-mono text-center mb-4 ${
        isDarkMode ? 'text-gray-300' : 'text-gray-600'
      }`}>
        {formatDate(time)}
      </div>

      {/* AM/PM Indicator - Improved Design */}
      <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-lg border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-sm ${
        time.getHours() >= 12 
          ? isDarkMode
            ? 'bg-orange-600 text-white border-orange-800 shadow-[2px_2px_0_0_rgba(194,65,12,0.5)]'
            : 'bg-orange-500 text-white border-orange-700 shadow-[2px_2px_0_0_rgba(194,65,12,0.4)]'
          : isDarkMode
            ? 'bg-blue-600 text-white border-blue-800 shadow-[2px_2px_0_0_rgba(30,64,175,0.5)]'
            : 'bg-blue-500 text-white border-blue-700 shadow-[2px_2px_0_0_rgba(30,64,175,0.4)]'
      }`}>
        <span className="text-xs opacity-75">
          {time.getHours() >= 12 ? '🌙' : '☀️'}
        </span>
        <span>
          {time.getHours() >= 12 ? 'PM' : 'AM'}
        </span>
      </div>

      {/* Time Zone */}
      <div className={`text-xs font-mono mt-3 ${
        isDarkMode ? 'text-gray-400' : 'text-gray-500'
      }`}>
        {Intl.DateTimeFormat().resolvedOptions().timeZone}
      </div>
    </div>
  );
}

export default DigitalClock; 