interface FunctionalButtonProps {
    number: string;
    onClick?: (value: string) => void;
    isDarkMode?: boolean;
}

function FunctionalButton(props : FunctionalButtonProps) {
    return (
        <button className={`font-mono font-bold text-xl w-16 h-16 rounded-md shadow-[2px_2px_0_0_rgba(80,80,80,0.5)] border-2 transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${props.isDarkMode ? 'bg-blue-500 hover:bg-blue-600 text-white border-blue-600' : 'bg-blue-400 hover:bg-blue-500 text-white border-blue-700'}`}
            onClick={() => props.onClick?.(props.number)}
        >
            {props.number}
        </button>
    )
}

export default FunctionalButton;