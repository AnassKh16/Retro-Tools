import { useState } from 'react';

interface HamburgerMenuProps {
  isDarkMode: boolean;
  onToolChange: (tool: string) => void;
  currentTool: string;
}

function HamburgerMenu({ isDarkMode, onToolChange, currentTool }: HamburgerMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const tools = [
    { id: 'calculator', name: 'Calculator', icon: '🧮' },
    { id: 'clock', name: 'Digital Clock', icon: '🕐' },
    { id: 'stopwatch', name: 'Stopwatch', icon: '⏱️' },
    { id: 'todo', name: 'To-Do List', icon: '📝' }
  ];

  const handleToolSelect = (toolId: string) => {
    onToolChange(toolId);
    setIsOpen(false);
  };

  return (
    <>
      {/* Hamburger Button - Positioned on NavBar */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`absolute top-4 left-4 z-50 p-2 rounded-md border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${
          isDarkMode 
            ? 'bg-gray-700 hover:bg-gray-600 text-white border-gray-600' 
            : 'bg-gray-300 hover:bg-gray-400 text-gray-900 border-gray-500'
        }`}
      >
        <div className="w-6 h-5 flex flex-col justify-between">
          <span className={`w-full h-0.5 transition-all duration-300 ${
            isOpen ? 'rotate-45 translate-y-2' : ''
          } ${isDarkMode ? 'bg-white' : 'bg-gray-900'}`}></span>
          <span className={`w-full h-0.5 transition-all duration-300 ${
            isOpen ? 'opacity-0' : ''
          } ${isDarkMode ? 'bg-white' : 'bg-gray-900'}`}></span>
          <span className={`w-full h-0.5 transition-all duration-300 ${
            isOpen ? '-rotate-45 -translate-y-2' : ''
          } ${isDarkMode ? 'bg-white' : 'bg-gray-900'}`}></span>
        </div>
      </button>

      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-64 z-50 transform transition-transform duration-300 ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } ${isDarkMode ? 'bg-gray-800 border-r-2 border-gray-600' : 'bg-gray-200 border-r-2 border-gray-400'}`}>
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center space-x-2 mb-8">
            <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM7 7h2v2H7V7zm0 4h2v2H7v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2zm-4 4h2v2h-2v-2zm4 0h2v2h-2v-2z"/>
              <path d="M9 9h2v2H9V9zm4 0h2v2h-2V9zm-4 4h2v2H9v-2zm4 0h2v2h-2v-2z"/>
            </svg>
            <h2 className={`font-mono font-bold text-xl tracking-wider ${
              isDarkMode ? 'text-white' : 'text-gray-900'
            }`}>
              RETRO TOOLS
            </h2>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-2">
            {tools.map((tool) => (
              <button
                key={tool.id}
                onClick={() => handleToolSelect(tool.id)}
                className={`w-full flex items-center space-x-3 p-3 rounded-md border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${
                  currentTool === tool.id
                    ? isDarkMode
                      ? 'bg-blue-600 border-blue-700 text-white'
                      : 'bg-blue-500 border-blue-600 text-white'
                    : isDarkMode
                    ? 'bg-gray-700 hover:bg-gray-600 border-gray-600 text-white'
                    : 'bg-gray-300 hover:bg-gray-400 border-gray-500 text-gray-900'
                }`}
              >
                <span className="text-2xl">{tool.icon}</span>
                <span className="font-mono font-bold">{tool.name}</span>
              </button>
            ))}
          </nav>

          {/* Footer */}
          <div className={`absolute bottom-6 left-6 right-6 p-4 rounded-md border-2 ${
            isDarkMode 
              ? 'bg-gray-700 border-gray-600 text-gray-300' 
              : 'bg-gray-300 border-gray-400 text-gray-700'
          }`}>
            <p className="text-sm font-mono text-center">
              More tools coming soon!
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default HamburgerMenu; 