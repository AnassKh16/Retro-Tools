interface UtilityButtonProps {
  number: string;
  onClick?: (value: string) => void;
  isDarkMode?: boolean;
}

function UtilityButton(props: UtilityButtonProps) {
    return (
        <button 
            className={`font-mono font-bold text-2xl w-16 h-16 rounded-md shadow-[2px_2px_0_0_rgba(80,80,80,0.5)] border-2 transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${props.isDarkMode ? 'bg-orange-500 hover:bg-orange-600 text-white border-orange-600' : 'bg-orange-400 hover:bg-orange-500 text-white border-orange-700'}`}
            onClick={() => props.onClick?.(props.number)}
        >
            {props.number}
        </button>
    )
}

export default UtilityButton;