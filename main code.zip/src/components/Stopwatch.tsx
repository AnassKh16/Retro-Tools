import { useState, useEffect } from 'react';

interface StopwatchProps {
  isDarkMode: boolean;
}

function Stopwatch({ isDarkMode }: StopwatchProps) {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let interval: number;
    if (isRunning) {
      interval = setInterval(() => {
        setTime(prevTime => prevTime + 10);
      }, 10);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const startStopwatch = () => {
    setIsRunning(true);
  };

  const stopStopwatch = () => {
    setIsRunning(false);
  };

  const resetStopwatch = () => {
    setIsRunning(false);
    setTime(0);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60000);
    const seconds = Math.floor((time % 60000) / 1000);
    const milliseconds = Math.floor((time % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}:${milliseconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`border-4 rounded-2xl shadow-[8px_8px_0_0_rgba(80,80,80,0.5)] p-8 w-[400px] h-[400px] flex flex-col items-center justify-center mt-20 transition-colors duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-600' : 'bg-gray-200 border-gray-700'}`}>
      <div className={`text-6xl font-mono font-bold mb-8 ${isDarkMode ? 'text-green-400' : 'text-gray-900'}`}>
        {formatTime(time)}
      </div>
      <div className="flex space-x-6">
        {!isRunning ? (
          <button 
            onClick={startStopwatch}
            className={`w-16 h-16 rounded-full border-4 shadow-[4px_4px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-lg transition-all duration-100 active:shadow-none active:translate-x-1 active:translate-y-1 ${
              isDarkMode 
                ? 'bg-green-600 hover:bg-green-700 text-white border-green-800' 
                : 'bg-green-500 hover:bg-green-600 text-white border-green-700'
            }`}
          >
            ▶
          </button>
        ) : (
          <button 
            onClick={stopStopwatch}
            className={`w-16 h-16 rounded-full border-4 shadow-[4px_4px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-lg transition-all duration-100 active:shadow-none active:translate-x-1 active:translate-y-1 ${
              isDarkMode 
                ? 'bg-red-600 hover:bg-red-700 text-white border-red-800' 
                : 'bg-red-500 hover:bg-red-600 text-white border-red-700'
            }`}
          >
            ⏸
          </button>
        )}
        <button 
          onClick={resetStopwatch}
          className={`w-16 h-16 rounded-full border-4 shadow-[4px_4px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-lg transition-all duration-100 active:shadow-none active:translate-x-1 active:translate-y-1 ${
            isDarkMode 
              ? 'bg-gray-600 hover:bg-gray-700 text-white border-gray-800' 
              : 'bg-gray-500 hover:bg-gray-600 text-white border-gray-700'
          }`}
        >
          ⏹
        </button>
      </div>
    </div>
  );
}

export default Stopwatch; 