import { useState } from 'react';

interface TodoListProps {
  isDarkMode: boolean;
}

interface Todo {
  id: number;
  text: string;
  completed: boolean;
}

function TodoList({ isDarkMode }: TodoListProps) {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [inputValue, setInputValue] = useState('');

  const addTodo = () => {
    if (inputValue.trim()) {
      const newTodo: Todo = {
        id: Date.now(),
        text: inputValue.trim(),
        completed: false
      };
      setTodos([...todos, newTodo]);
      setInputValue('');
    }
  };

  const toggleTodo = (id: number) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id: number) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addTodo();
    }
  };

  const completedCount = todos.filter(todo => todo.completed).length;
  const totalCount = todos.length;

  return (
    <div className={`border-4 rounded-2xl shadow-[8px_8px_0_0_rgba(80,80,80,0.5)] p-6 w-[400px] h-[500px] flex flex-col mt-20 transition-colors duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-600' : 'bg-gray-200 border-gray-700'}`}>
      {/* Header with Progress */}
      <div className={`text-2xl font-mono font-bold mb-4 text-center ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
        📝 To-Do List
      </div>
      
      {/* Progress Bar */}
      {totalCount > 0 && (
        <div className="mb-4">
          <div className={`w-full h-3 rounded-full border-2 ${
            isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-300 border-gray-400'
          }`}>
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                isDarkMode ? 'bg-green-500' : 'bg-green-600'
              }`}
              style={{ width: `${totalCount > 0 ? (completedCount / totalCount) * 100 : 0}%` }}
            ></div>
          </div>
          <div className={`text-xs font-mono text-center mt-1 ${
            isDarkMode ? 'text-gray-400' : 'text-gray-600'
          }`}>
            {completedCount} of {totalCount} completed
          </div>
        </div>
      )}
      
      {/* Input Section */}
      <div className="flex mb-4 space-x-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Add a new task..."
          className={`flex-1 p-3 rounded-md border-2 font-mono shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] transition-all duration-100 focus:shadow-none focus:translate-x-0.5 focus:translate-y-0.5 ${
            isDarkMode 
              ? 'bg-gray-700 text-white border-gray-600 placeholder-gray-400 focus:border-blue-500' 
              : 'bg-white text-gray-900 border-gray-400 placeholder-gray-500 focus:border-blue-600'
          }`}
        />
        <button
          onClick={addTodo}
          className={`px-4 py-3 rounded-md border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] font-mono font-bold transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${
            isDarkMode 
              ? 'bg-blue-600 hover:bg-blue-700 text-white border-blue-700' 
              : 'bg-blue-500 hover:bg-blue-600 text-white border-blue-600'
          }`}
        >
          ➕
        </button>
      </div>

      {/* Todo List */}
      <div className={`flex-1 overflow-y-auto p-4 rounded-lg border-2 ${
        isDarkMode ? 'bg-gray-900 border-gray-600' : 'bg-white border-gray-400'
      }`}>
        {todos.length === 0 ? (
          <div className={`text-center font-mono ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            <div className="text-4xl mb-2">📋</div>
            <p>No tasks yet. Add one above!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {todos.map(todo => (
              <div
                key={todo.id}
                className={`flex items-center justify-between p-4 rounded-lg border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] transition-all duration-200 hover:shadow-[3px_3px_0_0_rgba(0,0,0,0.4)] ${
                  todo.completed
                    ? isDarkMode
                      ? 'bg-green-900 border-green-600 opacity-75'
                      : 'bg-green-100 border-green-500 opacity-75'
                    : isDarkMode
                    ? 'bg-gray-800 border-gray-600 hover:border-gray-500'
                    : 'bg-gray-100 border-gray-300 hover:border-gray-400'
                }`}
              >
                <div className="flex items-center space-x-3 flex-1">
                  <button
                    onClick={() => toggleTodo(todo.id)}
                    className={`w-7 h-7 rounded-full border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-sm transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${
                      todo.completed
                        ? isDarkMode
                          ? 'bg-green-600 border-green-700 text-white'
                          : 'bg-green-500 border-green-600 text-white'
                        : isDarkMode
                        ? 'bg-gray-700 hover:bg-gray-600 border-gray-600 text-gray-400'
                        : 'bg-gray-300 hover:bg-gray-400 border-gray-500 text-gray-700'
                    }`}
                  >
                    {todo.completed ? '✓' : ''}
                  </button>
                  <span className={`font-mono flex-1 ${todo.completed ? 'line-through opacity-50' : ''} ${
                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                  }`}>
                    {todo.text}
                  </span>
                </div>
                <button
                  onClick={() => deleteTodo(todo.id)}
                  className={`w-7 h-7 rounded-full border-2 shadow-[2px_2px_0_0_rgba(0,0,0,0.3)] font-mono font-bold text-sm transition-all duration-100 active:shadow-none active:translate-x-0.5 active:translate-y-0.5 ${
                    isDarkMode 
                      ? 'bg-red-600 hover:bg-red-700 text-white border-red-700' 
                      : 'bg-red-500 hover:bg-red-600 text-white border-red-600'
                  }`}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default TodoList; 