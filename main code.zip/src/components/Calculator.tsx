import Button from './Button.tsx';
import UtilityButton from './UtilityButton.tsx';
import FunctionalButton from './FunctionalButton.tsx';

interface CalculatorProps {
  isDarkMode: boolean;
  screen: string;
  onNumberClick: (value: string) => void;
  onOperatorClick: (operator: string) => void;
  onEquals: () => void;
  onClear: () => void;
  onClearEntry: () => void;
}

function Calculator({ 
  isDarkMode, 
  screen, 
  onNumberClick, 
  onOperatorClick, 
  onEquals, 
  onClear, 
  onClearEntry 
}: CalculatorProps) {
  const displayValue = screen || '0';

  return (
    <div className={`border-4 rounded-2xl shadow-[8px_8px_0_0_rgba(80,80,80,0.5)] p-4 w-[400px] h-[500px] flex flex-col mt-20 transition-colors duration-300 ${isDarkMode ? 'bg-gray-800 border-gray-600' : 'bg-gray-200 border-gray-700'}`}>
      <div className={`text-4xl p-4 rounded-lg mb-2 border-2 shadow-inner font-mono tracking-widest select-none transition-all duration-300 ${isDarkMode ? 'bg-gray-900 text-green-400 border-green-600' : 'bg-gray-900 text-green-400 border-green-700'}`}>
        <div className="text-right truncate">{displayValue}</div>
      </div>
      <div className='flex-1 p-4 grid grid-cols-4 gap-2'>
        <Button number="7" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="8" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="9" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <UtilityButton number="÷" onClick={onOperatorClick} isDarkMode={isDarkMode} />
        <Button number="4" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="5" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="6" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <UtilityButton number="×" onClick={onOperatorClick} isDarkMode={isDarkMode} />
        <Button number="1" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="2" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="3" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <UtilityButton number="-" onClick={onOperatorClick} isDarkMode={isDarkMode} />
        <Button number="0" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="00" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <Button number="000" onClick={onNumberClick} isDarkMode={isDarkMode} />
        <UtilityButton number="+" onClick={onOperatorClick} isDarkMode={isDarkMode} />
        <Button number="." onClick={onNumberClick} isDarkMode={isDarkMode} />
        <FunctionalButton number="CE" onClick={onClearEntry} isDarkMode={isDarkMode} />
        <FunctionalButton number="C" onClick={onClear} isDarkMode={isDarkMode} />
        <FunctionalButton number="=" onClick={onEquals} isDarkMode={isDarkMode} />
      </div>
    </div>
  );
}

export default Calculator; 