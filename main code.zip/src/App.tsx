import './App.css';
import { useState } from 'react';
import NavBar from './components/NavBar.tsx';
import Calculator from './components/Calculator.tsx';
import DigitalClock from './components/DigitalClock.tsx';
import Stopwatch from './components/Stopwatch.tsx';
import TodoList from './components/TodoList.tsx';

function App() {
  const [screen, setScreen] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [currentTool, setCurrentTool] = useState('calculator');

  const handleNumberClick = (value: string) => {
    setScreen(prev => {
      // Limit total length to prevent overflow
      if (prev.length >= 15) return prev;
      
      // Prevent multiple leading zeros
      if (prev === '0' && value !== '.') return value;
      if (prev === '' && value === '0') return '0';
      
      return prev + value;
    });
  };

  const handleOperatorClick = (operator: string) => {
    setScreen(prev => {
      // Don't add operator if screen is empty or ends with operator
      if (prev === '' || /[+\-×÷]$/.test(prev)) return prev;
      return prev + operator;
    });
  };

  const handleEquals = () => {
    try {
      const sanitized = screen.replace(/×/g, '*').replace(/÷/g, '/');
      const result = eval(sanitized);
      
      // Check for integer overflow
      if (result > Number.MAX_SAFE_INTEGER || result < Number.MIN_SAFE_INTEGER) {
        setScreen('Error');
        return;
      }
      
      // Format result and limit length
      const formattedResult = Number.isInteger(result) 
        ? result.toString() 
        : result.toFixed(8).replace(/\.?0+$/, '');
      
      if (formattedResult.length > 15) {
        setScreen('Error');
        return;
      }
      
      setScreen(formattedResult);
    } catch {
      setScreen('Error');
    }
  };

  const handleClear = () => {
    setScreen('');
  };

  const handleClearEntry = () => {
    setScreen(prev => {
      return prev.slice(0, -1);
    });
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  const handleToolChange = (tool: string) => {
    setCurrentTool(tool);
    // Reset calculator when switching tools
    if (tool !== 'calculator') {
      setScreen('');
    }
  };

  // Render different tools based on currentTool
  const renderTool = () => {
    switch (currentTool) {
      case 'calculator':
        return (
          <Calculator
            isDarkMode={isDarkMode}
            screen={screen}
            onNumberClick={handleNumberClick}
            onOperatorClick={handleOperatorClick}
            onEquals={handleEquals}
            onClear={handleClear}
            onClearEntry={handleClearEntry}
          />
        );
      case 'clock':
        return <DigitalClock isDarkMode={isDarkMode} />;
      case 'stopwatch':
        return <Stopwatch isDarkMode={isDarkMode} />;
      case 'todo':
        return <TodoList isDarkMode={isDarkMode} />;
      default:
        return null;
    }
  };

  return (

    <div className={`min-h-screen flex justify-center items-center transition-colors duration-300 ${isDarkMode ? 'bg-gradient-to-br from-gray-900 to-gray-800' : 'bg-gradient-to-br from-blue-100 to-teal-200'}`}>
      <NavBar 
        isDarkMode={isDarkMode} 
        onToggleDarkMode={toggleDarkMode}
        onToolChange={handleToolChange}
        currentTool={currentTool}
      />
      {renderTool()}
    </div>

  )
}

export default App;
